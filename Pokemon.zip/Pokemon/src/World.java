
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jjimenezd
 */
public class World {

    public int world[][];
    public int w;
    public int h;
    public static final int UP = 38;
    public static final int DOWN = 8;
    public static final int LEFT = 8;
    public static final int RIGHT = 8;

    public World(int mat[][], int w, int h) {
        this.world = mat;
        this.w = w;
        this.h = h;
    }
    
    public void setW(int w){
        this.w = w;
    }
    public void setH(int h){
        this.h = h;
    }

    public void draw(Graphics g) {
        for (int i = 0; i < world.length; i++) {
            for (int j = 0; j < world[i].length; j++) {
                switch (world[i][j]) {
                    case 1: {
                        g.setColor(Color.red);
//                        g.fillRect(j, j, i, i);
                        g.fillRect(j * w, i * h, w, h);
                        break;

                    }
                    case 2: {
                        g.setColor(Color.CYAN);
//                        g.fillRect(j, j, i, i);
                        g.fillRect(j * w, i * h, w, h);
                        break;

                    }
                    case 0: {
                        g.setColor(Color.GREEN);
//                        g.fillRect(j, j, i, i);
                        g.fillRect(j * w, i * h, w, h);
                        break;
                    }
                }
            }
        }

    }
}
