
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class PrimeraVista extends JFrame{
    
    private JList lista;
    private JButton boton;
    private DefaultListModel modelo;
    private Pokemon pokePlayer = null;
    private ArrayList<Pokemon> pokemones;
    
    public PrimeraVista(ArrayList<Pokemon> p){
        
        pokemones = p;
        modelo = new DefaultListModel();
        lista = new JList();
        boton = new JButton("Empezar");
        lista.setModel(modelo);
        final PrimeraVista estaVista = this;
        boton.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me) {
                if(lista.getSelectedValue() == null){
                    JOptionPane.showMessageDialog(null, "Escoge un pokemon");
                    return;
                }
                for(Pokemon q : pokemones){
                    if(q.toString().equals(lista.getSelectedValue().toString())){
                        Game.g.J1.pokemon = q;
                        System.out.println(q);
                        Game.g.setVisible(true);
                        Game.g.movieLoop.start();
                        estaVista.setVisible(false);
                        break;
                    }
                }
            }
            
        });
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(430,200);
        setSize(500,300);
        setLayout(new BorderLayout());
        
        
//        JPanel panel1 = new JPanel();

        
        modelo.clear();
        for(Pokemon pok : pokemones){
            modelo.addElement(pok);
        }
        
        add(lista, BorderLayout.CENTER);
        add(boton, BorderLayout.SOUTH);
    }
    
}
