
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lgguzman
 */
public class Game extends JFrame{
    
    public ArrayList<Pokemon> pokemones;
    public Thread movieLoop;
    public Canvas c;
    public Avatar J1;
    public World mundo;
    public MundoFoto mundof;
    public int tam = 40;
    public Pokemon pp;
    public String pp1;
    public int vida;
    public int vidaj;
    public static int world[][] = {
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
        {1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1}};
    
    
    public void obtenerPokemones() throws IOException{
        LeerArchivo la = new LeerArchivo("pokemones.txt");
        Pokemon p = la.leer();
        while(p!= null){
            pokemones.add(p);
            p = la.leer();
        }
    }
    
    public void obtenerPokemon(int [][] mat, int x, int y, int w, int h){
        for(Pokemon p:pokemones){
            System.out.println((int)(x/w)+" "+(int)(y/h));
            if((int)(x)==p.m && (int)(y) == p.n){
                pp=p;
            }
        }
    }
    
    public void ataque(){
        int rand;
        if (J1.pokemon.getTipo().equals(pp.getDebilidad())) {
            rand=(int)(Math.random()*40);
            vida=vida-rand;
        }else{
            if (!J1.pokemon.getTipo().equals(pp.getDebilidad())) {
                rand=(int)(Math.random()*20);
                vida-=rand;
            }else{
                if (J1.pokemon.getTipo().equals(pp.getFortaleza())) {
                    rand=(int)(Math.random()*15);
                    vida-=rand;
                }
            }
        }
    }
    
    public void ataqueRecibido(){
        int rand;
        if (pp.getFortaleza().equals(J1.pokemon.getTipo())) {
            rand=(int)(Math.random()*40);
            vidaj=vidaj-rand;           
        }
    }
    
    public void colocarPokemones(){
        int cont = 0;
        do{
            int n = (int)(Math.random()*24);
            int m = (int)(Math.random()*20);
            int p = (int)(Math.random()*5);
            
            if(world[m][n]==0){
                world[m][n] = 2;
                pokemones.get(p).m = m;
                pokemones.get(p).n = n;
                pp = pokemones.get(p);
                cont++;
                System.out.println(m+","+n+","+pp);
            }
        }while(cont<5);
    }
    
    public Game(int w, int h) throws IOException {
        pokemones = new ArrayList();
        
        EscribirArchivo ea = new EscribirArchivo("pokemones.txt");
        if(ea.vacio){
            
            iniPokemons();
            for(Pokemon p : pokemones){
                ea.escribir(p);
            }
            
            ea.close();
        }else{
            
            obtenerPokemones();
        }
        
        colocarPokemones();
        
        
        setIconImage(new ImageIcon(getClass().getResource("sprites/icono.png")).getImage());
        setTitle("Pokemon");
        setLocation(300,100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());
        
        try {
            c = new Canvas();
            this.setSize(w, h);
            c.setSize(w, h);
            this.add(c, BorderLayout.CENTER);
            
            
            this.addKeyListener(new KeyListener() {

                @Override
                public void keyTyped(KeyEvent e) {
                    //throw new UnsupportedOperationException("Not supported yet.");
                }

                @Override
                public void keyPressed(KeyEvent e) {
                    if(e.getKeyChar()=='a' || e.getKeyChar() == 'A'){
                        System.out.println(c.getMousePosition());
                        return;
                    }
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_UP: {
                            J1.currentDirection = Avatar.UP;
                            break;
                        }
                        case KeyEvent.VK_DOWN: {
                            J1.currentDirection = Avatar.DOWN;
                            break;
                        }
                        case KeyEvent.VK_LEFT: {
                            J1.currentDirection = Avatar.LEFT;
                            break;
                        }
                        case KeyEvent.VK_RIGHT: {
                            J1.currentDirection = Avatar.RIGTH;
                            break;
                        }
                    }
                    //throw new UnsupportedOperationException("Not supported yet.");
                }

                @Override
                public void keyReleased(KeyEvent e) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_UP: {
                            J1.currentDirection = Avatar.NONE;
                            break;
                        }
                        case KeyEvent.VK_DOWN: {
                            J1.currentDirection = Avatar.NONE;
                            break;
                        }
                        case KeyEvent.VK_LEFT: {
                            J1.currentDirection = Avatar.NONE;
                            break;
                        }
                        case KeyEvent.VK_RIGHT: {
                            J1.currentDirection = Avatar.NONE;
                            break;
                        }
                    }
                    //throw new UnsupportedOperationException("Not supported yet.");
                }
            });
            final Game q = this;
            J1 = new Avatar(250, 250, 2, 2, "sprites");
            String[] names = {"arriba", "right", "abajo", "left"};
            J1.loadPics(names);
            mundo = new World(world, c.getWidth()/24, c.getHeight()/20);
            mundof = new MundoFoto(new ImageIcon(getClass().getResource("sprites/pokemundo.png")).getImage(),0,0,600,500);
            movieLoop = new Thread(new Runnable() {
                @Override
                public void run() {
                    c.createBufferStrategy(2);
                    Graphics g = c.getBufferStrategy()
                            .getDrawGraphics();

                    long startTime = System.currentTimeMillis();
                    long currentTime = 0;
                    mundo.setW((c.getWidth())/24);
                    mundo.setH((c.getHeight())/20);
                    J1.setH((c.getHeight())/20);
                    J1.setW((c.getWidth())/24);
                    
                    while (true) {
                        g = c.getBufferStrategy()
                            .getDrawGraphics();
                        try {
                            
                            currentTime = System.currentTimeMillis() - startTime;
                            
                            mundo.draw(g);
                            mundof.draw(g);
                            J1.draw(g);
                            
                            if(J1.encuentraPokemon(world, mundo.w, mundo.h)){
                                
                                if(JOptionPane.showConfirmDialog(null, "Pelear?", "Encontraste un "+pp.getNombre(), JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                                    vida=pp.getHpMax();
                                    while(vida>0){
                                    if(JOptionPane.showConfirmDialog(null, "Atacar","Pelea",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                                        obtenerPokemon(world, J1.x, J1.y, mundo.w, mundo.h);
                                        ataque();
                                        JOptionPane.showMessageDialog(null,pp.getNombre()+" "+vida);
            
                                    }
                                    }
                                }
                             
                                J1.currentDirection = Avatar.NONE;
                            }
                            
                            switch (J1.currentDirection) {
                                case Avatar.UP: {
                                    J1.moveUp(currentTime, mundo, c.getWidth(),c.getHeight());
                                    mundof.cam(J1, c.getWidth(), c.getHeight(),1);
                                    break;
                                }
                                case Avatar.DOWN: {
                                    J1.moveDown(currentTime, mundo,c.getWidth(),c.getHeight());
                                    mundof.cam(J1, c.getWidth(), c.getHeight(),1);
                                    break;
                                }
                                case Avatar.LEFT: {
                                    J1.moveLeft(currentTime, mundo,c.getWidth(),c.getHeight());
                                    mundof.cam(J1, c.getWidth(), c.getHeight(),0);
                                    break;
                                }
                                case Avatar.RIGTH: {
                                    J1.moveRight(currentTime, mundo,c.getWidth(),c.getHeight());
                                    mundof.cam(J1, c.getWidth(), c.getHeight(),0);
                                    break;
                                }
                            }
                            
                            
                            c.getBufferStrategy().show();
                            Thread.sleep(10);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    public void iniPokemons(){
        Pokemon p = new Pokemon("Pikachu", "Electrico", "Tierra", "Agua", 100, 50, 60, null);
        Pokemon evo = new Pokemon("Raichu", "Electrico", "Tierra", "Agua", 150, 70, 80, null);
        p.setEvolucion(evo);
        pokemones.add(p);
        
        p = new Pokemon("Squirtle", "Agua", "Planta", "Fuego", 100, 50, 60, null);
        evo = new Pokemon("Blastoise", "Agua", "Planta", "Fuego", 150, 60, 70, null);
        p.setEvolucion(evo);
        pokemones.add(p);
        
        p = new Pokemon("Charmander", "Fuego", "Agua", "Planta", 100, 50, 50, null);
        evo = new Pokemon("Charizard", "Fuego", "Agua", "Planta", 150, 70, 90, null);
        p.setEvolucion(evo);
        pokemones.add(p);
        
        p = new Pokemon("Bulbasaur", "Planta", "Fuego", "Tierra", 100, 40, 50, null);
        evo = new Pokemon("Bulbasaur", "Planta", "Fuego", "Tierra", 150, 70, 50, null);
        p.setEvolucion(evo);
        pokemones.add(p);
        
        p = new Pokemon("Geodude", "Tierra", "Agua", "Electrico", 100, 50, 50, null);
        evo = new Pokemon("Graveler", "Tierra", "Agua", "Electrico", 150, 70, 80, null);
        p.setEvolucion(evo);
        pokemones.add(p);
    }
    
    
    public static Inicio v1;
    public static Game g;
    public static PrimeraVista pv;
    
    public static void main(String[] args) throws IOException {
        g = new Game(606, 528);
        pv = new PrimeraVista(g.pokemones);
        v1 = new Inicio();

        
//        g.setVisible(true);
//        g.movieLoop.start();
        v1.setVisible(true);
    }
}
