
import java.awt.Graphics;
import java.awt.Image;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class MundoFoto {
    Image img;
    int x;
    int y;
    int w;
    int h;
    
    public MundoFoto(Image img, int x, int y, int w, int h){
        this.img = img;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    
    public void cam(Avatar b, int w, int h, int sw){
        if(sw==0){
            if(x<0 && b.x<w/2){
                x+=b.vx;
                b.x += b.vx;
            }else if( x+this.w>w && b.x>w/2){
                x-=b.vx;
                b.x -= b.vx;
            }
        }else{
            if(y<0 && b.y<h/2){
               y+=b.vy;
               b.y += b.vy;
           }else if( y+this.h>h && b.y>h/2){
               y-=b.vy;
               b.y -= b.vy;
           }
        }
    }
    
    public void draw(Graphics g){
        g.drawImage(img, x, y, w, h, null);
    }
}
