
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class LeerArchivo {
    
    BufferedReader br;
    
    public LeerArchivo(String url) throws FileNotFoundException, IOException{
        File f = new File(url);
        if(f.exists()){
            br=new BufferedReader(new FileReader(f));
        }
        
    }
    
    
    public Pokemon leer() throws  IOException{
        String st = br.readLine();
        
        if(st != null){
            String s[] = st.split(";");
            int hp=-1, ata = -1, def = -1, hp1=-1, ata1 = -1, def1 = -1; 
            try{
                hp = Integer.parseInt(s[4]);
                ata = Integer.parseInt(s[5]);
                def = Integer.parseInt(s[6]);
                hp1 = Integer.parseInt(s[11]);
                ata1 = Integer.parseInt(s[12]);
                def1 = Integer.parseInt(s[13]);
            }catch(Exception ex){}
            
            Pokemon p = new Pokemon(s[0], s[1],s[2],s[3],hp,ata,def, null);
            Pokemon evo = new Pokemon(s[7], s[8],s[9],s[10],hp1,ata1,def1, null);
            
            p.setEvolucion(evo);
            
            return p;
        }
        
        return null;
    }
    
  
    
    public void close() throws IOException{
        br.close();
    }
}
