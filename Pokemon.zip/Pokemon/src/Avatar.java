
import java.awt.Graphics;
import java.io.Serializable;
import javax.swing.ImageIcon;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lgguzman
 */
public class Avatar{

    public static final int UP = 0;
    public static final int RIGTH = 1;
    public static final int DOWN = 2;
    public static final int LEFT = 3;
    public static final int NONE = -1;
    Animation[] animations;
    public int x;
    public int y;
    public int vx;
    public int vy;
    public int currentAnimation;
    public int currentDirection;
    public int w;
    public int h;
    String path;
    public Pokemon pokemon;

    public Avatar(int x, int y, int vx, int vy, String path) {
        this.path = path;
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.currentDirection = -1;
        animations = new Animation[4];
        
        this.w = 0;
        this.h = 0;
    }

    public void setW(int w) {
        this.w = w;
    }

    public void setH(int h) {
        this.h = h;
    }
    
    

    public void loadPics(String[] names) throws Exception {
        for (int j = 0; j < 4; j++) {
            String name = names[j];
            animations[j] = new Animation();
            for (int i = 1; i <= 3; i++) {
                animations[j].addScene(
                        new ImageIcon(getClass().getResource(path + "/" + name + i + ".png")).getImage(), 100);
            }
        }

    }

    public int posInMatrix(int px, int tam) {
        return (px) / tam;
    }

    public boolean isValid(int[][] mat, int w, int h, int x, int y, int tw, int th) {
        if(y<0 || x<0 || x>tw-tw%24-1 || y>th-th%20-1)return false;
        return mat[posInMatrix(y, h)][posInMatrix(x, w)] == 0 || mat[posInMatrix(y, h)][posInMatrix(x, w)] == 2;
    }
    
    public boolean encuentraPokemon(int[][] mat, int w, int h){
        if(mat[posInMatrix(y, h)][posInMatrix(x, w)] == 2){
            mat[posInMatrix(y, h)][posInMatrix(x, w)] = 0;
            return true;
        }
        
        return false;
    }

    public void moveUp(long time, World world, int tw, int th) {
        if (isValid(world.world, world.w, world.h, x+3, y - vy, tw, th) && isValid(world.world, world.w, world.h, x+this.w-3, y - vy, tw, th)) {
//            
            y -= vy;

        }
        currentAnimation = Avatar.UP;
        animations[Avatar.UP].update(time);
    }

    public void moveDown(long time, World world,int tw, int th) {
        if (isValid(world.world, world.w, world.h, x+3, y + vy+this.h, tw , th) && isValid(world.world, world.w, world.h, x+this.w-3, y + vy + this.h, tw, th)) {
            y += vy;

        }
        currentAnimation = Avatar.DOWN;
        animations[Avatar.DOWN].update(time);
    }

    public void moveLeft(long time, World world,int tw, int th) {

        if (isValid(world.world, world.w, world.h, x - vx+3, y,tw,th) && isValid(world.world, world.w, world.h, x - vx+3, y+this.h,tw,th)) {
            
            x -= vx;
        }
        currentAnimation = Avatar.LEFT;
        animations[Avatar.LEFT].update(time);
    }

    public void moveRight(long time, World world, int tw, int th) {
        if (isValid(world.world, world.w, world.h, x + vx + this.w-3, y,tw,th) && isValid(world.world, world.w, world.h, x + vx + this.w-3, y+this.h,tw,th)) {
           
            x += vx;

        }
        currentAnimation = Avatar.RIGTH;
        animations[Avatar.RIGTH].update(time);
    }
    
    public void draw(Graphics g) {
        
        
        g.drawImage(animations[currentAnimation].getImage(), x, y, w,h, null);
    }

}
