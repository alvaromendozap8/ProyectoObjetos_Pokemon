
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuario
 */
public class EscribirArchivo {
    
    File f;
    PrintWriter pw;
    boolean vacio;
   
    public EscribirArchivo(String url) throws IOException{
        f = new File(url);
        if(!f.exists()){
            f.createNewFile();
        }
        vacio = vacio();
        pw = new PrintWriter(new FileWriter(url, true));
    }
    
    public void escribir(Pokemon p){
        pw.println(p.registro()+";"+p.getEvolucion().registro());
    }
    
    public boolean vacio() throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader(f));
        if(br.readLine()!=null){
            
            br.close();
            return false;
        }
        
        br.close();
        return true;
    }
    
   
    
    public void close(){
        pw.close();
    }
}
