public class Pokemon {
    
    
    private String nombre;
    private String tipo;
    private String debilidad;
    private String fortaleza;
    private int hpMax;
    private int ataqueMax;
    private int defMax;
    private Pokemon evolucion;
    
    int m;
    int n;

    public Pokemon(String nombre, String tipo, String debilidad, String fortaleza, int hpMax, int ataqueMax, int defMax, Pokemon evo) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.debilidad = debilidad;
        this.fortaleza = fortaleza;
        this.hpMax = hpMax;
        this.ataqueMax = ataqueMax;
        this.defMax = defMax;
        
        m=n=-1;
        evolucion = evo;
    }

    public Pokemon getEvolucion() {
        return evolucion;
    }

    public void setEvolucion(Pokemon evolucion) {
        this.evolucion = evolucion;
    }
    
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDebilidad() {
        return debilidad;
    }

    public void setDebilidad(String debilidad) {
        this.debilidad = debilidad;
    }

    public String getFortaleza() {
        return fortaleza;
    }

    public void setFortaleza(String fortaleza) {
        this.fortaleza = fortaleza;
    }

    public int getHpMax() {
        return hpMax;
    }

    public void setHpMax(int hpMax) {
        this.hpMax = hpMax;
    }

    public int getAtaqueMax() {
        return ataqueMax;
    }

    public void setAtaqueMax(int ataqueMax) {
        this.ataqueMax = ataqueMax;
    }

    public int getDefMax() {
        return defMax;
    }

    public void setDefMax(int defMax) {
        this.defMax = defMax;
    }
    
    public String registro(){
        
        return nombre+";"+tipo+";"+debilidad+";"+fortaleza+";"+hpMax+";"+ataqueMax+";"+defMax;


    }

    @Override
    public String toString() {
        return "Pokemon{" + "nombre=" + nombre + ", tipo=" + tipo + ", debilidad=" + debilidad + ", fortaleza=" + fortaleza + ", hpMax=" + hpMax + ", ataqueMax=" + ataqueMax + ", defMax=" + defMax + ", evolucion=" + evolucion + '}';
    }
    
    
    
    
}
